# Stage 134 — Full-field HPR v0 vs v3.1 historical reconstruction

## Why this exists

Stage 133 correctly returned `INSUFFICIENT_ELIGIBLE_RACES`: its sparse HPR v3.1 database (originally constructed for a set of active horses) has no completed, fully HPR-covered 2024–2025 starting fields. That should not be read as proof for or against the new model.

Stage 134 **reconstructs both versions for all exact-reference UK/IE race starters** from the immutable Kaggle-derived archive. It uses the original Stage 86 HPR scoring function and applies the Stage 132 class, opposition mean OR and relative weight formula. A third option further adjusts v3.1 for **today’s declared weight, official mark and explicit class**, mirroring Stage 132 paper-selection logic. Previous-day-only form is used to rank races; the current race's result is added to the state only after its selections have been made. It refuses a race if one or more runners has no same-discipline prior record or if the winner/identities are unverifiable. No odds or SP enter any predicted HPR.

**Important:** A reconstructed v0 or v3.1 rating is not a copy of the sparse, persisted HPR ledger. This replay is a controlled historical research comparison and cannot alone establish live effectiveness.

## Upload

1. `stage134_full_field_hpr_replay.py` → `scripts/`
2. `stage134-full-field-hpr-replay.yml` → `.github/workflows/`

Run **Actions → Stage134 - Full-field HPR v0 vs v3.1 chronological reconstruction → Run workflow**, with default **2022-01-01 history; 2024-01-01 to 2025-12-31 evaluation**.

## Results

- `stage134-hpr-replay-audit.json`: race count, verified dates, unique IDs, full-field coverage/rejections, same-code form exclusions and summaries.
- `stage134-hpr-paired-races.csv`: one row per eligible exact race; old v0 / new v3.1 / new v3.1 with today-conditions selection, results, SP, and differences.
- `stage134-hpr-by-discipline-racetype.csv`: strike rate and SP ROI broken out for all, individual years, hurdle and chase handicaps, other disciplines, and country, including all three research variants.

All result files are uploaded as a GitHub Actions artifact. Workflow never commits or updates data, the live site or existing models. Historical SP settlement is not morning-price ROI. A small eligible sample is flagged as inadequate rather than called successful predictive validation.

## Stage134 failed run 43742300119 — fix (15 November 2026)

The original synthetic fixture accidentally assigned a fifth-place result in a four-runner race. Stage86 properly rejected that invalid position, causing the fixture assertion to fail (7 instead of 8 scored performances) before any historical files downloaded. The corrected fixture assigns 1st/2nd/3rd/4th exactly once for the second race, validates both mock finishing orders, and passes the local Python smoke test.

If Stage134 files are already in the repository, **replace ONLY `scripts/stage134_full_field_hpr_replay.py`**. The `.github/workflows/stage134-full-field-hpr-replay.yml` file is unchanged. Rerun the workflow from Actions with the default dates. This local test is not evidence the historical backtest ran or is profitable.
